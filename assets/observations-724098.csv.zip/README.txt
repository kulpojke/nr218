Exported at 2026-05-01T19:18:31Z

Query: quality_grade=any&identifications=any&iconic_taxa%5B%5D=Reptilia&iconic_taxa%5B%5D=Amphibia&swlat=33.99769740776757&swlng=-119.443692832877&nelat=34.024164354573735&nelng=-119.33794942467388&verifiable=true&spam=false

Columns:
id: Unique, sequential identifier for the observation
uuid: Universally unique identifier for the observation. See https://datatracker.ietf.org/doc/html/rfc9562
observed_on_string: Date/time as entered by the observer
observed_on: Normalized date of observation
time_observed_at: Normalized datetime of observation
quality_grade: Quality grade of this observation. See Help section for details on what this means. See https://help.inaturalist.org/support/solutions/articles/151000169936
description: Text written by the observer describing the observation or recording any other notes that seem relevant
num_identification_disagreements: Number of identifications associated with taxa that do not match and are not contained by the taxon from the observer's identification
captive_cultivated: Observation is of an organism that exists in the time and place it was observed because humans intended it to be then and there. For more, see https://help.inaturalist.org/support/solutions/articles/151000169932
latitude: Publicly visible latitude from the observation location
longitude: Publicly visible longitude from the observation location
positional_accuracy: Coordinate precision (yeah, yeah, accuracy != precision, poor choice of names)
private_latitude: Private latitude, set if observation private or obscured
private_longitude: Private longitude, set if observation private or obscured
public_positional_accuracy: Maximum horizontal positional uncertainty in meters; includes uncertainty added by coordinate obscuration
geoprivacy: Whether or not the observer has chosen to obscure or hide the coordinates. See https://help.inaturalist.org/support/solutions/articles/151000169938
taxon_geoprivacy: Most conservative geoprivacy applied due to the conservation statuses of taxa in current identification.
coordinates_obscured: Whether or not the coordinates have been obscured, either because of geoprivacy or because of a threatened taxon
positioning_method: How the coordinates were determined
species_guess: Plain text name of the observed taxon; can be set by the observer during observation creation, but can get replaced with canonical, localized names when the taxon changes
scientific_name: Scientific name of the observed taxon according to iNaturalist
common_name: Common or vernacular name of the observed taxon according to iNaturalist
iconic_taxon_name: Higher-level taxonomic category for the observed taxon
taxon_id: Unique, sequential identifier for the observed taxon

For more information about column headers, see https://www.inaturalist.org/terminology

