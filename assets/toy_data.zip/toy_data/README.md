## README toy_data
This is directory has subdirectories the names of which are self explanatory.
